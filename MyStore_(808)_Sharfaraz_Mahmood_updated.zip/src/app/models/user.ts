export class User {
    userName : string ;
    address: string ;
    creditCardNumber: string ;
  
    constructor(){
        this.userName = "";
        this.address = "";
        this.creditCardNumber = "";
    }
}
